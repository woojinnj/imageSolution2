import sys
import os
import logging
import threading
import zlib
import base64
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QApplication, QSystemTrayIcon, QAction, QMenu
from PyQt5.QtGui import QIcon
from fastapi import FastAPI, HTTPException, Depends
from fastapi.responses import HTMLResponse
from sqlalchemy import create_engine, Column, Integer, String, LargeBinary, MetaData,Table
from sqlalchemy.orm import declarative_base, sessionmaker
from ui_basic04 import LogViewer  # 새로 만든 UI 파일 임포트
from ui_basic04 import QTextEditLogger
from db_info04 import engine, Session
import platform
from ui_dbinfo_mod04 import Mainwindow
from db_info04 import update_engine
import enum
from sqlalchemy.types import Enum
from sqlalchemy import text

# SQLAlchemy 및 데이터베이스 설정
Base = declarative_base()

metadata = MetaData(schema="public")
metadata.reflect(bind=engine)

enddevice = Table("enddevice", metadata, autoload_with=engine)
content = Table("content", metadata, autoload_with=engine)

# print(enddevice.columns.keys())  # enddevice 테이블의 컬럼 목록 출력
# print(content.columns.keys())    # content 테이블의 컬럼 목록 출력

# class StatusEnum(enum.Enum):
#     timeout="TIMEOUT"
#     success = "SUCCESS"
#     unassigned = "UNASSIGNED"

# FastAPI 애플리케이션 생성
fastapi_app = FastAPI()


def get_db():
    """SQLAlchemy 세션을 최신 엔진과 연결된 상태로 제공"""
    db = Session()  # 최신 세션 객체 사용
    try:
        yield db
    finally:
        db.close()
        print("close 성공")


@fastapi_app.get("/")
def read_root():
    logging.info("메인 화면에 접속했습니다.")
    return {"message": "메인 화면 입니다!"}


@fastapi_app.get("/image/all2", response_class=HTMLResponse)
def get_all_images2(
        page: int = 1,
        per_page: int = 10,
        q: str = "",
        status: str = "",  # 상태 필터 (예: SUCCESS, TIMEOUT, UNASSIGNED)
        db: Session = Depends(get_db)
):

    offset = (page - 1) * per_page

    # enddevice와 content 테이블을 조인하는 SQL (서브쿼리로 각 code의 최신 content 선택)
    sql = text("""
        WITH latest_enddevice AS (
            SELECT DISTINCT ON (code) *
            FROM public.enddevice
            ORDER BY code, id DESC
        ),
        latest_content AS (
            SELECT DISTINCT ON (SPLIT_PART(code, '-', 1)) *
            FROM public.content
            ORDER BY SPLIT_PART(code, '-', 1), id DESC
        )
        SELECT 
            e.state, 
            e.code,
            c.id,
            c.code,
            c."content"
        FROM latest_enddevice e
        LEFT JOIN latest_content c
            ON e.code = SPLIT_PART(c.code, '-', 1)
        ORDER BY e.id
        
    """)

    params = {"q": q, "status": status, "offset": offset, "limit": per_page}
    results = db.execute(sql, params).fetchall()

    if not results:
        return HTMLResponse(content=f"<h1>'{q}'와 상태 '{status}'에 해당하는 데이터가 없습니다.</h1>", status_code=404)

    # 전체 행 수를 조회 (페이징 처리를 위해)
    count_sql = text("""
        SELECT COUNT(*)
        FROM public.enddevice e
        WHERE (:q = '' OR e.code ILIKE '%' || :q || '%')
          AND (:status = '' OR e.state = :status)
    """)
    total_rows = db.execute(count_sql, {"q": q, "status": status}).scalar()
    total_pages = (total_rows // per_page) + (1 if total_rows % per_page > 0 else 0)

    # HTML 컨텐츠 생성 (각 row: state, code, 이미지)
    html = "<div class='image-gallery'>"
    for state, ed_code, _, _, content in results:
        encoded_image = ""  # 기본값 설정

        if content is not None and content != "string":  # "string"인 경우 무시
            try:
                # Base64 디코딩 후 zlib 압축 해제
                decoded = base64.b64decode(content)
                decompressed = zlib.decompress(decoded)

                # HTML <img> 태그에 들어갈 수 있도록 다시 Base64 인코딩
                encoded_image = base64.b64encode(decompressed).decode('utf-8')
            except Exception as e:
                logging.error(f"이미지 처리 에러(code={ed_code}): {e}")
                encoded_image = ""

        # HTML에 이미지 추가
        html += f"""
            <div class="image-container" style="margin-bottom:20px;">
                <h2>Code: {ed_code} (State: {state})</h2>
                <img src="data:image/jpeg;base64,{encoded_image}" alt="Image-{ed_code}" style="max-width:300px;">
            </div>
        """

    html += "</div>"

    # 페이징 및 검색 관련 HTML (자바스크립트 포함)
    pagination_html = f"""
    <div class="pagination">
        {"<button onclick='goToPage(1)'>&laquo;</button>" if page > 1 else ""}
        {"<button onclick='goToPage(" + str(page - 1) + ")'>&lt;</button>" if page > 1 else ""}
        <span>페이지 {page} / {total_pages}</span>
        <select id="per-page" class="per-page-select" onchange="changePerPage()">
            <option value="10" {"selected" if per_page == 10 else ""}>10개씩 보기</option>
            <option value="20" {"selected" if per_page == 20 else ""}>20개씩 보기</option>
            <option value="50" {"selected" if per_page == 50 else ""}>50개씩 보기</option>
            <option value="{total_rows}" {"selected" if per_page == total_rows else ""}>전체 보기</option>
        </select>
        {"<button onclick='goToPage(" + str(page + 1) + ")'>&gt;</button>" if page < total_pages else ""}
        {"<button onclick='goToPage(" + str(total_pages) + ")'>&raquo;</button>" if page < total_pages else ""}
    </div>
    """

    # 전체 HTML 문서 (검색창, 페이징 스크립트 포함)
    full_html = f"""
    <html>
        <head>
            <title>갤러리 (페이지 {page})</title>
            <style>
                .image-gallery {{
                    display: flex;
                    flex-wrap: wrap;
                    gap: 10px;
                    padding: 30px;
                    justify-content: center;
                }}
                .image-container {{
                    width: calc(25% - 10px);
                    text-align: center;
                }}
                .pagination {{
                    position: fixed;
                    bottom: 20px;
                    left: 50%;
                    transform: translateX(-50%);
                    display: flex;
                    gap: 10px;
                    background: rgba(255, 255, 255, 0.9);
                    padding: 10px 20px;
                    border-radius: 10px;
                    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
                }}
                .per-page-select {{
                    font-size: 14px;
                    padding: 5px;
                    border-radius: 5px;
                    border: 1px solid #ccc;
                }}
                .search-container {{
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    gap: 10px;
                    margin: 20px auto;
                    width: fit-content;
                }}
            </style>
            <script>
                function goToPage(page) {{
                    let query = document.getElementById("search-box").value;
                    let status = document.getElementById("status-select").value;
                    window.location.href = `/image/all2?q=${{query}}&status=${{status}}&page=${{page}}&per_page={per_page}`;
                }}
                function changePerPage() {{
                    let selectedPerPage = document.getElementById("per-page").value;
                    let query = document.getElementById("search-box").value;
                    let status = document.getElementById("status-select").value;
                    window.location.href = `/image/all2?q=${{query}}&status=${{status}}&page=1&per_page=${{selectedPerPage}}`;
                }}
                function searchImages() {{
                    let query = document.getElementById("search-box").value;
                    let status = document.getElementById("status-select").value;
                    window.location.href = `/image/all2?q=${{query}}&status=${{status}}&page=1&per_page={per_page}`;
                }}
            </script>
        </head>
        <body>
            <h1 style="text-align:center;">갤러리</h1>
            <div class="search-container">
                <input type="text" id="search-box" placeholder="Code 검색..." value="{q}" onkeyup="if(event.keyCode === 13) searchImages()">
                <select id="status-select" onchange="searchImages()">
                    <option value="" {"selected" if status == "" else ""}>전체</option>
                    <option value="SUCCESS" {"selected" if status == "SUCCESS" else ""}>SUCCESS</option>
                    <option value="TIMEOUT" {"selected" if status == "TIMEOUT" else ""}>TIMEOUT</option>
                    <option value="UNASSIGNED" {"selected" if status == "UNASSIGNED" else ""}>UNASSIGNED</option>
                </select>
                <button onclick="searchImages()">검색</button>
            </div>
            {html}
            {pagination_html}
        </body>
    </html>
    """

    logging.info(f"검색어 '{q}', 상태 '{status}' 적용 - 페이지 {page}")
    return HTMLResponse(content=full_html)


# PyQt 메인 함수
if __name__ == "__main__":
    if not QtWidgets.QApplication.instance():  # 기존 인스턴스가 없을 때만 생성
        qt_app = QtWidgets.QApplication(sys.argv)



    # Dock 아이콘 클릭 시 동작 설정
    def on_focus_changed(old_widget, new_widget):
        if not viewer.isVisible():
            viewer.show()


    qt_app.focusChanged.connect(on_focus_changed)

    # Dock 아이콘 설정
    path = os.path.join(
        os.path.dirname(sys.modules[__name__].__file__),
        '/Users/woojin/Desktop/test/imageSolution/images/moonicon.png',
    )
    qt_app.setWindowIcon(QIcon(path))

    viewer = LogViewer(app=fastapi_app)
    db_window = Mainwindow()

    viewer.setWindowTitle("로그뷰어")
    db_window.setWindowTitle("DB CONNECTION SETTINGS")

    # 시스템 트레이 설정
    tray_icon = QSystemTrayIcon(QIcon(path), qt_app)
    tray_menu = QMenu()

    restore_action = QAction("창 열기", viewer)
    restore_action.triggered.connect(viewer.show)  # 트레이에서 창 열기

    quit_action = QAction("종료", viewer)
    quit_action.triggered.connect(qt_app.quit)  # 앱 종료

    db_mod_open_action = QAction("db연결 수정", viewer)
    db_mod_open_action.triggered.connect(db_window.show)  # db연결 정보 수정하기

    tray_menu.addAction(restore_action)
    tray_menu.addAction(db_mod_open_action)
    tray_menu.addAction(quit_action)

    tray_icon.setContextMenu(tray_menu)
    tray_icon.show()

    viewer.show()
    sys.exit(qt_app.exec_())
