from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from fastapi import FastAPI, HTTPException, Depends


# PostgreSQL 연결 정보
db_info_core = {
    "username": "aims",
    "password": "aims",
    "database": "AIMS_CORE_DB",
    "host": "1.220.2.154",
    "port": "15987",

}

def get_core_db_url():
    """현재 db_info를 바탕으로 DB URL 생성"""
    return f"postgresql+psycopg://{db_info_core['username']}:{db_info_core['password']}@{db_info_core['host']}:{db_info_core['port']}/{db_info_core['database']}"


# SQLAlchemy 엔진 및 세션 생성
engine = create_engine(get_core_db_url(), echo=True)
Session = sessionmaker(bind=engine)


def update_engine():
    global engine, Session
    engine.dispose()
    engine = create_engine(get_core_db_url(), echo=True)
    Session = sessionmaker(bind=engine)
    print("AIMS_CORE_DB 정보 수정됨")

db_info_portal = {
    "username": "aims",
    "password": "aims",
    "database": "AIMS_PORTAL_DB",
    "host": "1.220.2.154",
    "port": "15987",
}

def get_portal_db_url():
    return f"postgresql+psycopg://{db_info_portal['username']}:{db_info_portal['password']}@{db_info_portal['host']}:{db_info_portal['port']}/{db_info_portal['database']}"


engine_portal = create_engine(get_portal_db_url(), echo=True)
SessionPortal = sessionmaker(bind=engine_portal)


def update_portal_engine():
    global engine_portal, SessionPortal
    engine_portal.dispose()
    engine_portal = create_engine(get_portal_db_url(), echo=True)
    SessionPortal = sessionmaker(bind=engine_portal)
    print("AIMS_PORTAL_DB 정보 수정됨")